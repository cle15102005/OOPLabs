package ranint.huy.enemy;

import ranint.linh.character.Character;

public class norEnemy extends Enemy {
	public norEnemy(String enemyName,String infor,int ene_HP,int ene_DEF,int ene_ATT, double point) {
		super(enemyName,infor,ene_HP,ene_DEF,ene_ATT, point);
	}
	
	public norEnemy(int ene_HP, double point) {
		super(ene_HP, point);
	}
	@Override
	public void getDamage(int ATT) {
		super.getDamage(ATT);
	}
	
	public void normalATT(Character character) {
		super.normalATT(character);
	}
}